
function drawer(){
    let pagePath = window.location.pathname;
    // alert(pagePath);
}

function showBeta(){
    
}